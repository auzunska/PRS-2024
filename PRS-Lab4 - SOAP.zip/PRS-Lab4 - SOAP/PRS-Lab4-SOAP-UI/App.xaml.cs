﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace PRS_Lab4_SOAP_UI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
